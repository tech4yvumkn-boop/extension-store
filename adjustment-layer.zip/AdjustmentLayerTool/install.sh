#!/bin/bash
# ============================================================
# Adjustment Layer Tool - Premiere Pro Extension Installer
# Mac ke liye - CEP Extension install karta hai
# ============================================================

echo "🎬 Adjustment Layer Tool - Installer"
echo "======================================"

# Extension folder paths
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
CEP_EXTENSIONS_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
EXTENSION_NAME="AdjustmentLayerTool"
INSTALL_PATH="$CEP_EXTENSIONS_DIR/$EXTENSION_NAME"

echo "📁 Source: $SOURCE_DIR"
echo "📂 Install target: $INSTALL_PATH"
echo ""

# CEP extensions folder banao agar nahi hai
if [ ! -d "$CEP_EXTENSIONS_DIR" ]; then
    echo "📂 CEP Extensions folder bana rahe hain..."
    mkdir -p "$CEP_EXTENSIONS_DIR"
fi

# Purani installation remove karo
if [ -d "$INSTALL_PATH" ]; then
    echo "🗑️  Purani installation remove ho rahi hai..."
    rm -rf "$INSTALL_PATH"
fi

# Extension copy karo
echo "📦 Extension copy ho rahi hai..."
cp -r "$SOURCE_DIR" "$INSTALL_PATH"

echo "✅ Extension install ho gayi: $INSTALL_PATH"
echo ""

# PlayerDebugMode enable karo (developer mode ke liye zaruri)
echo "🔧 Developer mode enable ho raha hai..."
defaults write com.adobe.CSXS.11 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.10 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.9  PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.8  PlayerDebugMode 1 2>/dev/null
echo "✅ Developer mode enabled!"
echo ""

echo "🎉 Installation complete!"
echo ""
echo "👉 Ab karo:"
echo "   1. Adobe Premiere Pro restart karo"
echo "   2. Window menu → Extensions → 'Adjustment Layer Tool'"
echo "   3. Timeline mein clips select karo"
echo "   4. 'Adjustment Layer Add Karo' button dabao!"
echo ""
echo "⚠️  Agar extension nahi dikh rahi:"
echo "   - Premiere Pro completely quit karke dobara open karo"
echo "   - macOS Security settings mein extension allow karo"
