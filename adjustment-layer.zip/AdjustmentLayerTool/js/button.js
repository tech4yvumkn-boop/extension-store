var csInterface;
try { csInterface = new CSInterface(); } catch(e) {}

var btnMiniAdd = document.getElementById('btnMiniAdd');

btnMiniAdd.addEventListener('click', function() {
    var script = 'triggerAddFromMiniPanel()';
    csInterface.evalScript(script, function(r) {
        // We can just log to extension console or do nothing
        console.log(r);
    });
});
