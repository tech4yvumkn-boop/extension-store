/**
 * Adjustment Layer Tool - main.js v5.1 (Preset Mode with Tabs)
 */

var csInterface;
try { csInterface = new CSInterface(); } catch(e) { console.error('CSInterface:', e); }

// DOM
var btnDebug          = document.getElementById('btnDebug');
var btnRefreshPresets = document.getElementById('btnRefreshPresets');
var logArea           = document.getElementById('logArea');
var loader            = document.getElementById('loadingIndicator');
var presetBoxContainer = document.getElementById('presetBoxContainer');
var manualStart       = document.getElementById('manualStart');
var manualEnd         = document.getElementById('manualEnd');

// Tabs and Panels
var tabSelected   = document.getElementById('tabSelected');
var tabAll        = document.getElementById('tabAll');
var tabManual     = document.getElementById('tabManual');
var panelSelected = document.getElementById('panelSelected');
var panelAll      = document.getElementById('panelAll');
var panelManual   = document.getElementById('panelManual');

var currentMode = 'selected';
var currentPresetId = ""; // empty means Blank Layer

// ---- Utils ----
function tc(s) {
    if (s == null || isNaN(s)) return '--';
    var m = Math.floor(s / 60), sec = Math.floor(s % 60);
    return (m < 10?'0':'')+m+':'+(sec<10?'0':'')+sec;
}

function showLog(msg, type) {
    try {
        var icons = { success:'✅', error:'❌', info:'ℹ️', warn:'⚠️' };
        var d = document.createElement('div');
        d.className = 'log-message --'+(type||'info');
        d.innerHTML = '<span class="log-icon">'+(icons[type]||'ℹ️')+'</span><span>'+msg+'</span>';
        if (logArea) {
            logArea.innerHTML = '';
            logArea.appendChild(d);
        }
    } catch(e) { console.error(e); }
}

function clearLog() { if (logArea) logArea.innerHTML = ''; }

function setLoading(on) {
    if (loader) loader.classList.toggle('--visible', on);
    if (btnRefreshPresets) btnRefreshPresets.disabled = on;
}

function runScript(script, cb) {
    if (!csInterface) { cb('{"error":"CSInterface nahi mila"}'); return; }
    try {
        csInterface.evalScript(script, function(r) {
            cb((!r || r==='undefined'||r==='null') ? '{"error":"Script ne koi response nahi diya"}' : r);
        });
    } catch(e) { cb('{"error":"evalScript error: '+e.message+'"}'); }
}

function parse(s) {
    try { return JSON.parse(s); } catch(e) { return { error: 'Parse error: '+String(s).substr(0,80) }; }
}

// ---- SYNC STATE TO HOST ----
function syncStateToHost() {
    try {
        var pId = currentPresetId || "";
        var mStart = manualStart ? parseFloat(manualStart.value) || 0 : 0;
        var mEnd   = manualEnd ? parseFloat(manualEnd.value) || 10 : 10;
        
        var script = 'setGlobalState("' + currentMode + '", ' + mStart + ', ' + mEnd + ', "' + pId + '")';
        runScript(script, function(){});
    } catch(e) {
        showLog("Sync error: " + e.message, "error");
    }
}

if (manualStart) manualStart.addEventListener('input', syncStateToHost);
if (manualEnd) manualEnd.addEventListener('input', syncStateToHost);

function setMode(mode) {
    currentMode = mode;
    
    if (tabSelected) tabSelected.classList.remove('active');
    if (tabAll) tabAll.classList.remove('active');
    if (tabManual) tabManual.classList.remove('active');
    
    if (panelSelected) panelSelected.classList.remove('active');
    if (panelAll) panelAll.classList.remove('active');
    if (panelManual) panelManual.classList.remove('active');
    
    if (panelSelected) panelSelected.style.display = 'none';
    if (panelAll) panelAll.style.display = 'none';
    if (panelManual) panelManual.style.display = 'none';

    if (mode === 'selected') {
        if (tabSelected) tabSelected.classList.add('active');
        if (panelSelected) { panelSelected.classList.add('active'); panelSelected.style.display = 'flex'; }
    } else if (mode === 'all') {
        if (tabAll) tabAll.classList.add('active');
        if (panelAll) { panelAll.classList.add('active'); panelAll.style.display = 'flex'; }
    } else {
        if (tabManual) tabManual.classList.add('active');
        if (panelManual) { panelManual.classList.add('active'); panelManual.style.display = 'flex'; }
    }
    syncStateToHost();
}

if (tabSelected) tabSelected.addEventListener('click', function() { setMode('selected'); });
if (tabAll) tabAll.addEventListener('click', function() { setMode('all'); });
if (tabManual) tabManual.addEventListener('click', function() { setMode('manual'); });

function renderPresets(presets) {
    if (!presetBoxContainer) return;
    presetBoxContainer.innerHTML = '';
    
    // Always add Blank Layer
    var blankBox = document.createElement('div');
    blankBox.className = 'preset-box ' + (currentPresetId === '' ? 'selected' : '');
    blankBox.dataset.id = '';
    blankBox.innerHTML = '<span class="icon">⬛</span><span class="name">Blank Layer</span>';
    presetBoxContainer.appendChild(blankBox);

    // Add other presets
    if (presets && presets.length > 0) {
        for (var i = 0; i < presets.length; i++) {
            var box = document.createElement('div');
            var isSel = (currentPresetId === presets[i].id) ? 'selected' : '';
            box.className = 'preset-box ' + isSel;
            box.dataset.id = presets[i].id;
            box.innerHTML = '<span class="icon">🎨</span><span class="name">' + presets[i].name + '</span>';
            presetBoxContainer.appendChild(box);
        }
    }

    var boxes = presetBoxContainer.querySelectorAll('.preset-box');
    boxes.forEach(function(b) {
        b.addEventListener('click', function() {
            boxes.forEach(function(bx) { bx.classList.remove('selected'); });
            b.classList.add('selected');
            currentPresetId = b.dataset.id;
            syncStateToHost();
        });
    });
    
    syncStateToHost();
}

// ---- DEBUG ----
if (document.getElementById('appHeader')) {
    document.getElementById('appHeader').addEventListener('dblclick', function() {
        if (btnDebug) btnDebug.style.display = (btnDebug.style.display==='none') ? 'block' : 'none';
    });
}

if (btnDebug) {
    btnDebug.addEventListener('click', function() {
        setLoading(true);
        runScript('debugInfo()', function(r) {
            setLoading(false);
            var d = parse(r);
            if (d.error) { showLog('Debug error: '+d.error, 'error'); return; }
            var msg = [
                'PPro '+d.appVersion,
                'Seq: '+(d.hasSequence?'Y':'N'),
                'Proj: '+(d.hasPresetsProject?'Y':'N')
            ].join(' | ');
            showLog(msg, 'info');
        });
    });
}

// ---- LOAD PRESETS ----
function loadPresets() {
    try {
        setLoading(true);
        showLog('Presets load kar rahe hain...', 'info');
        
        var extPath = csInterface ? csInterface.getSystemPath(SystemPath.EXTENSION) : '';
        extPath = extPath.replace(/\\/g, '/');

        var script = 'getPresetsList("' + extPath + '")';
        
        runScript(script, function(r) {
            try {
                setLoading(false);
                var d = parse(r);
                var combinedPresets = [];
                
                if (d.success && d.presets && d.presets.length > 0) {
                    combinedPresets = combinedPresets.concat(d.presets);
                }
                
                if (d.error && combinedPresets.length === 0) { 
                    showLog(d.error, 'error'); 
                    renderPresets([]); 
                    return; 
                }
                
                if (combinedPresets.length > 0) {
                    renderPresets(combinedPresets);
                    showLog(combinedPresets.length + ' presets mil gaye.', 'success');
                } else {
                    renderPresets([]);
                    showLog('Presets folder mein koi preset nahi mila.', 'warn');
                }
            } catch(cbErr) {
                setLoading(false);
                showLog('Callback error: ' + cbErr.message, 'error');
            }
        });
    } catch(err) {
        setLoading(false);
        showLog('Load error: ' + err.message, 'error');
    }
}

if (btnRefreshPresets) {
    btnRefreshPresets.addEventListener('click', loadPresets);
}

// ---- INIT ----
window.addEventListener('load', function() {
    setTimeout(function() {
        loadPresets();
    }, 500); // add a slight delay to let Premiere fully initialize
});

