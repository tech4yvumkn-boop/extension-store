/**
 * Adjustment Layer Tool - ExtendScript (Minimal Button Mode)
 */

if (typeof JSON === 'undefined') {
    JSON = {};
    JSON.stringify = function(obj) {
        var t = typeof obj;
        if (t === 'undefined') return 'null';
        if (t === 'number' || t === 'boolean') return String(obj);
        if (t === 'string') return '"' + obj.replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\n/g,'\\n') + '"';
        if (obj === null) return 'null';
        if (obj instanceof Array) {
            var a = []; for (var i=0;i<obj.length;i++) a.push(JSON.stringify(obj[i]));
            return '['+a.join(',')+']';
        }
        var p = [];
        for (var k in obj) { if(obj.hasOwnProperty(k)) p.push('"'+k+'":'+JSON.stringify(obj[k])); }
        return '{'+p.join(',')+'}';
    };
}

// ============================================================
// HELPER: Selected clips
// ============================================================
function findSelectedClips(sequence) {
    var selected = [];
    var tracks   = sequence.videoTracks;
    for (var t = 0; t < tracks.numTracks; t++) {
        var clips = tracks[t].clips;
        for (var c = 0; c < clips.numItems; c++) {
            try {
                var clip = clips[c];
                var sel  = false;
                if (typeof clip.isSelected === 'function') sel = clip.isSelected();
                else if (typeof clip.selected !== 'undefined') sel = !!clip.selected;
                if (sel) selected.push({ start: clip.start.seconds, end: clip.end.seconds, track: t, name: clip.name||'Clip' });
            } catch(e) {}
        }
    }
    if (selected.length === 0) {
        try {
            if (typeof sequence.getSelection === 'function') {
                var sel2 = sequence.getSelection();
                if (sel2 && sel2.length > 0) {
                    for (var s=0;s<sel2.length;s++) {
                        try { selected.push({ start:sel2[s].start.seconds, end:sel2[s].end.seconds, track:0, name:sel2[s].name||'Clip' }); } catch(e2) {}
                    }
                }
            }
        } catch(e) {}
    }
    return selected;
}

function findEffectiveStart(targetTrack, desiredStart, desiredEnd) {
    var eff = desiredStart;
    try {
        var clips = targetTrack.clips;
        for (var c = 0; c < clips.numItems; c++) {
            try {
                var cl = clips[c];
                if (cl.start.seconds <= desiredStart + 0.05 && cl.end.seconds > desiredStart + 0.05) {
                    if (cl.end.seconds < desiredEnd && cl.end.seconds > eff) eff = cl.end.seconds;
                }
            } catch(e) {}
        }
    } catch(e) {}
    return eff;
}

function trimToExactEnd(targetTrack, clipStartSec, desiredEndSec) {
    var done = false;
    for (var ci = 0; ci < targetTrack.clips.numItems; ci++) {
        try {
            var cl = targetTrack.clips[ci];
            if (Math.abs(cl.start.seconds - clipStartSec) < 0.3) {
                var curEnd = cl.end.seconds;
                if (Math.abs(curEnd - desiredEndSec) < 0.1) { done = true; break; }

                var eTime = new Time();
                eTime.seconds = desiredEndSec;

                try { cl.end = eTime; done = true; } catch(e1) {}
                if (!done) {
                    try {
                        var shift  = curEnd - desiredEndSec;
                        var newOut = new Time();
                        newOut.seconds = cl.outPoint.seconds - shift;
                        cl.outPoint = newOut;
                        done = true;
                    } catch(e2) {}
                }
                break;
            }
        } catch(e) {}
    }
    return done;
}

function searchBinForAdj(bin) {
    try {
        var children = bin.children;
        for (var i = 0; i < children.numItems; i++) {
            try {
                var item = children[i];
                if (item.name && item.name.toLowerCase().indexOf('adjustment') !== -1) return item;
                if (item.children && item.children.numItems > 0) {
                    var found = searchBinForAdj(item);
                    if (found) return found;
                }
            } catch(e) {}
        }
    } catch(e) {}
    return null;
}

// ============================================================
// GLOBAL STATE FOR MINI PANEL COMMUNICATION
// ============================================================
function triggerAddFromMiniPanel() {
    return addAdjustmentLayer('selected', 0, 10, null, '');
}

// ============================================================
// FUNCTION: Add Preset Adjustment Layer
// ============================================================
function addAdjustmentLayer(mode, manualStart, manualEnd, targetTrackIndex, presetId) {
    try {
        var project  = app.project;
        var sequence = project ? project.activeSequence : null;
        if (!project)  return '{"error":"Koi project nahi hai"}';
        if (!sequence) return '{"error":"Koi sequence nahi hai"}';
        
        // Find any adjustment layer in the project
        var presetItem = searchBinForAdj(project.rootItem);
        if (!presetItem) return '{"error":"Project mein koi Blank Adjustment Layer nahi mili. Pehle Premiere mein ek Adjustment Layer banayein."}';

        var tracks = sequence.videoTracks;
        var overallStart = 0; var overallEnd = 10; var maxTrack = 0;

        // Selected clips mode
        var clips = findSelectedClips(sequence);
        if (clips.length===0) return '{"error":"Koi clip select nahi hua."}';
        
        overallStart=clips[0].start; overallEnd=clips[0].end; maxTrack=clips[0].track;
        for (var i=1;i<clips.length;i++) {
            if(clips[i].start<overallStart)overallStart=clips[i].start;
            if(clips[i].end>overallEnd)overallEnd=clips[i].end;
            if(clips[i].track>maxTrack)maxTrack=clips[i].track;
        }

        var useTrack = maxTrack + 1;
        if (useTrack >= tracks.numTracks) useTrack = tracks.numTracks - 1;
        if (useTrack < 0) useTrack = 0;

        var targetTrack    = tracks[useTrack];
        var finalStart     = findEffectiveStart(targetTrack, overallStart, overallEnd);
        var finalEnd       = overallEnd;
        var targetDuration = finalEnd - finalStart;

        if (targetDuration <= 0.05) {
            return JSON.stringify({ error:'Track V'+(useTrack+1)+' pe koi jagah nahi hai.', noSpace:true });
        }

        var startTime = new Time(); startTime.seconds = finalStart;
        
        var success=false, methodUsed='', errors=[];

        try {
            if (typeof sequence.overwriteClip === 'function') {
                var oldIn = null, oldOut = null;
                try { oldIn = presetItem.getInPoint(); oldOut = presetItem.getOutPoint(); } catch(e) {}

                var tIn = new Time(); tIn.seconds = 0;
                var tOut = new Time(); tOut.seconds = targetDuration;
                
                try { presetItem.setInPoint(tIn, 4); } catch(e) { try { presetItem.setInPoint(tIn); } catch(e2){} }
                try { presetItem.setOutPoint(tOut, 4); } catch(e) { try { presetItem.setOutPoint(tOut); } catch(e2){} }

                sequence.overwriteClip(presetItem, startTime, useTrack, -1);
                var trimDone = trimToExactEnd(targetTrack, finalStart, finalEnd);
                success = true; methodUsed = 'overwriteClip';
                
                if (oldIn) { try { presetItem.setInPoint(oldIn, 4); } catch(e) { try { presetItem.setInPoint(oldIn); } catch(e2){} } }
                if (oldOut) { try { presetItem.setOutPoint(oldOut, 4); } catch(e) { try { presetItem.setOutPoint(oldOut); } catch(e2){} } }
            } else { 
                errors.push('sequence.overwriteClip method nahi hai'); 
            }
        } catch(mC) { errors.push('C: '+mC.message); }

        if (success) {
            return JSON.stringify({ success:true, method:methodUsed, trackIndex:useTrack,
                startTime:finalStart, endTime:finalEnd, duration:targetDuration,
                skippedStart:finalStart-overallStart });
        }

        return JSON.stringify({
            error: 'Preset add karne mein error: ' + errors.join('\n')
        });

    } catch(e) {
        return '{"error":"Main: '+e.message.replace(/"/g,"'")+'"}';
    }
}
